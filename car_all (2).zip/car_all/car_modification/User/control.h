#ifndef __TEST_H
#define __TEST_H
extern int change_flag;
extern int Obstacle_flag;
int echo(void);
void control(void);
void Obstacle(void);
#endif
