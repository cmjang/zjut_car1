void All_Init(void);
