#ifndef __SIGNAL_H
#define __SIGNAL_H


#include <stm32f4xx.h>
#include <stdio.h>

extern char Front0,Front1,Front2,Front3,Front4,Behind0,Behind1,Behind2;
extern char F_Infrared_L,F_Infrared_R,Infrared_01,Infrared_02;

void get_signal(void);

#endif
