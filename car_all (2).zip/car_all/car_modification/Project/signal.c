#include  "signal.h"
#include  <stm32f4xx.h>
#define NUM 5.0

char Front0,Front1,Front2,Front3,Front4,Behind0,Behind1,Behind2;
char F_Infrared_L,F_Infrared_R,Infrared_01,Infrared_02;
char Front[5][10];//[????????0-7][????,0????]
char Infrared[4][10];//[??2????2???0-2][????,0????]
char Behind[3][10];//[????????0-7][????,0????]

void get_signal(void)
{  
    for(int i=NUM;i>0;i--)                 //??
    {
      for(int j=4;j>=0;j--)
      {
        Front[j][i]=Front[j][i-1];
      }
      for(int n=1;n>=0;n--)
      {
        Infrared[n][i]=Infrared[n][i-1];
      }
			for(int k=2;k>=0;k--)
      {
        Behind[k][i]=Behind[k][i-1];
      }
    }
    Front[0][0]=GPIO_ReadInputDataBit(GPIOC,GPIO_Pin_5);
    Front[1][0]=GPIO_ReadInputDataBit(GPIOC,GPIO_Pin_6);
    Front[2][0]=GPIO_ReadInputDataBit(GPIOC,GPIO_Pin_8);
    Front[3][0]=GPIO_ReadInputDataBit(GPIOC,GPIO_Pin_9);
    Front[4][0]=GPIO_ReadInputDataBit(GPIOB,GPIO_Pin_8);
    
		Behind[0][0]=GPIO_ReadInputDataBit(GPIOB,GPIO_Pin_7);
    Behind[1][0]=GPIO_ReadInputDataBit(GPIOB,GPIO_Pin_0);
    Behind[2][0]=GPIO_ReadInputDataBit(GPIOC,GPIO_Pin_3);
		
    Infrared[0][0]=GPIO_ReadInputDataBit(GPIOC,GPIO_Pin_10);
    Infrared[1][0]=GPIO_ReadInputDataBit(GPIOC,GPIO_Pin_11);
    Infrared[2][0]=0;
    Infrared[3][0]=0;
   
    Front0=0;Front1=0;Front2=0;Front3=0;Front4=0;Behind0=0;Behind1=0;Behind2=0;
    F_Infrared_L=0;F_Infrared_R=0;Infrared_01=0;Infrared_02=0;
    for(int i=NUM;i>=0;i--)
    {
        Front0+=Front[0][i];
        Front1+=Front[1][i];
        Front2+=Front[2][i];
        Front3+=Front[3][i];
        Front4+=Front[4][i];
			
			
        Behind0+=Behind[0][i];
        Behind1+=Behind[1][i];
        Behind2+=Behind[2][i];

        F_Infrared_L+=Infrared[0][i];
        F_Infrared_R+=Infrared[1][i];
        Infrared_01+=Infrared[2][i];
        Infrared_02+=Infrared[3][i];
    }
    Front0=(Front0<(NUM/2))?1:0;
    Front1=(Front1<(NUM/2))?1:0;
    Front2=(Front2<(NUM/2))?1:0;
    Front3=(Front3<(NUM/2))?1:0;
    Front4=(Front4<(NUM/2))?1:0;
		Front0=1-Front0;
				Front1=1-Front1;
				Front2=1-Front2;
				Front3=1-Front3;
						Front4=1-Front4;
		

    Behind0=(Behind0>(NUM/2))?1:0;
    Behind1=(Behind1>(NUM/2))?1:0;
    Behind2=(Behind2>(NUM/2))?1:0;
		
    F_Infrared_L=(F_Infrared_L>(NUM/2))?1:0;
    F_Infrared_R=(F_Infrared_R>(NUM/2))?1:0;  
    Infrared_01=(Infrared_01>(NUM/2))?1:0;
    Infrared_02=(Infrared_02>(NUM/2))?1:0;  

}